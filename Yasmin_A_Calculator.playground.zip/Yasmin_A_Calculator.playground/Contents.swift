import Cocoa


/* For this operators are still new to me so i made a simple calculator with simple numbers. as again im still testing out operators so their might be bugs. */

//division

for index in 1...1 {
    print("\(index) divided by 1 is \(index / 1)")
}
for index in 1...2 {
    print("\(index) divided by 2 is \(index / 2)")
}
for index in 1...3 {
    print("\(index) divided by 3 is \(index / 3)")
}
for index in 1...4 {
    print("\(index) divided by 4 is \(index / 4)")
}
for index in 1...5 {
    print("\(index) divided by 5 is \(index / 5)")
}
for index in 1...6 {
    print("\(index) divided by 6 is \(index / 6)")
}
for index in 1...7 {
    print("\(index) divided by 7 is \(index / 7)")
}
for index in 1...8 {
    print("\(index) divided by 8 is \(index / 8)")
}
for index in 1...9 {
    print("\(index) divided by 9 is \(index / 9)")
}
for index in 1...10 {
    print("\(index) divided by 10 is \(index / 10)")
}

//subtraction

for index in 1...1 {
    print("\(index) subtracted by 1 is \(index - 1)")
}
for index in 1...2 {
    print("\(index) subtracted by 2 is \(index - 2)")
}
for index in 1...3 {
    print("\(index) subtracted by 3 is \(index - 3)")
}
for index in 1...4 {
    print("\(index) subtracted by 4 is \(index - 4)")
}
for index in 1...5 {
    print("\(index) subtracted by 5 is \(index - 5)")
}
for index in 1...6 {
    print("\(index) subtracted by 6 is \(index - 6)")
}
for index in 1...7 {
    print("\(index) subtracted by 7 is \(index - 7)")
}
for index in 1...8 {
    print("\(index) subtracted by 8 is \(index - 8)")
}
for index in 1...9 {
    print("\(index) subtracted by 9 is \(index - 9)")
}
for index in 1...10 {
    print("\(index) subtracted by 10 is \(index - 10)")
}

//Multiplication

for index in 1...1 {
    print("\(index) times 1 is \(index * 1)")
}
for index in 1...2 {
    print("\(index) times 2 is \(index * 2)")
}
for index in 1...3 {
    print("\(index) times 3 is \(index * 3)")
}
for index in 1...4 {
    print("\(index) times 4 is \(index * 4)")
}
for index in 1...5 {
    print("\(index) times 5 is \(index * 5)")
}
for index in 1...6 {
    print("\(index) times 6 is \(index * 6)")
}
for index in 1...7 {
    print("\(index) times 7 is \(index * 7)")
}
for index in 1...8 {
    print("\(index) times 8 is \(index * 8)")
}
for index in 1...9 {
    print("\(index) times 9 is \(index * 9)")
}
for index in 1...10 {
    print("\(index) times 10 is \(index * 10)")
}


//addition

for index in 1...1 {
    print("\(index) plus 1 is \(index + 1)")
}
for index in 1...2 {
    print("\(index) plus 2 is \(index + 2)")
}
for index in 1...3 {
    print("\(index) plus 3 is \(index + 3)")
}
for index in 1...4 {
    print("\(index) plus 4 is \(index + 4)")
}
for index in 1...5 {
    print("\(index) plus 5 is \(index + 5)")
}
for index in 1...6 {
    print("\(index) plus 6 is \(index + 6)")
}
for index in 1...7 {
    print("\(index) plus 7 is \(index + 7)")
}
for index in 1...8 {
    print("\(index) plus 8 is \(index + 8)")
}
for index in 1...9 {
    print("\(index) plus 9 is \(index + 9)")
}
for index in 1...10 {
    print("\(index) plus 10 is \(index + 10)")
}
